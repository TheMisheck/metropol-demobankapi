package com.metropol.demobank.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;
import java.util.UUID;

@MappedSuperclass
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class AbstractEntity implements Serializable{

    protected static final class CLAUSES {
        public static final String NOT_DELETED = "deleted_at IS NULL";
    }

    @Id
    @Column(name = "id", updatable = false, nullable = false)
    private String id;



    protected Date updatedAt;
    protected Date createdAt;
    private Date deletedAt;


    protected AbstractEntity() {
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }


    public Date getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Date updatedAt) {
        this.updatedAt = updatedAt;
    }


    public Date getDeletedAt() {
        return deletedAt;
    }

    public void setDeletedAt(Date deletedAt) {
        this.deletedAt = deletedAt;
    }

    public String getId() {
        return id;
    }

    @PrePersist
    void prePersist() {
        this.id = UUID.randomUUID().toString();
        this.createdAt = new Date();
    }

    @PreUpdate
    void preUpdate() {
        this.updatedAt = new Date();
    }

    @PreRemove
    void preRemove() {
    }

    @PostLoad
    void postLoad() {
    }

    @PostRemove
    void postRemove() {
    }

    @PostUpdate
    void postUpdate() {
    }

    @PostPersist
    void postPersist() {
    }
}
