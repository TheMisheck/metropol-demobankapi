package com.metropol.demobank.log;
import java.util.Arrays;
public class BeeLog {
    private static final String TAG = "BeeLog";

    private static final boolean DEBUG = true;

    public static boolean isDebug() {
        return DEBUG;
    }

    public static void log(Object msg) {
        log(TAG, msg);
    }

    public static void print(Exception e) {
        if (e == null) {
            return;
        }
        if (isDebug()){
            e.printStackTrace();
        }
        log(TAG, Arrays.toString(e.getStackTrace()));
    }

    public static void print(Throwable e) {
        if (e == null) {
            return;
        }
        if (isDebug()){
            e.printStackTrace();
        }
        log(TAG, Arrays.toString(e.getStackTrace()));
    }

    public static void log(String tag, Object msg) {
        if (DEBUG) {
            System.out.println(String.valueOf(tag) + ": " + String.valueOf(msg));
        }
        MetropolLogger.getInstance().log(tag, String.valueOf(msg));
    }


    public static void error(Object msg) {
        if (DEBUG) {
            System.err.println(String.valueOf(TAG) + ": " + String.valueOf(msg));
        }

        MetropolLogger.getInstance().log(TAG, String.valueOf(msg));
    }
}
