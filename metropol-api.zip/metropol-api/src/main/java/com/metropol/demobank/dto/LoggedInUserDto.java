package com.metropol.demobank.dto;

import com.metropol.demobank.model.User;

public class LoggedInUserDto {
    private String username;
    private String email;
    private String firstName;
    private String middleName;
    private String lastName;
    private String token;

    public LoggedInUserDto(User user, String token) {
        this.username = user.getUsername();
        this.email = user.getEmail();
        this.firstName = user.getFirstName();
        this.middleName = user.getMiddleName();
        this.lastName = user.getLastName();
        this.token = token;
    }

    public String getUsername() {
        return username;
    }

    public String getEmail() {
        return email;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getToken() {
        return token;
    }
}
