package com.metropol.demobank;

import com.metropol.demobank.repository.UserRepository;
import com.metropol.demobank.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import com.metropol.demobank.model.User;
@SpringBootApplication
public class DemoBankApplication { //implements CommandLineRunner
    private final
    UserRepository userRepository;

    private final
    UserService userService;


    @Autowired
    public DemoBankApplication(UserService userService,
                               UserRepository userRepository) {
        this.userService = userService;
        this.userRepository = userRepository;
    }

	public static void main(String[] args) {
		SpringApplication.run(DemoBankApplication.class, args);
	}

//	@Override
//    public void run(String... params) {
//        userRepository.deleteAll();
//        User admin = new User();
//        admin.setUsername("admin");
//        admin.setPassword("admin");
//        admin.setEmail("info@metropol.com");
//        admin.setFirstName("Admin First Name");
//        admin.setMiddleName("Admin Middle Name");
//        admin.setLastName("Admin Last Name");
//        userService.addUser(admin);
//        userService.addUser(admin);
//    }

}

