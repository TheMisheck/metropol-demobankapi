package com.metropol.demobank.model;

import org.hibernate.annotations.Where;

import javax.persistence.*;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.util.Date;

@Entity
@Table(name = "t_customers")
public class Customer extends AbstractEntity {

}
