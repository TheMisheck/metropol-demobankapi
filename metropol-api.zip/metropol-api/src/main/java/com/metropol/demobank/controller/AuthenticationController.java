package com.metropol.demobank.controller;

import com.metropol.demobank.auth.TokenProvider;
import com.metropol.demobank.dto.LoggedInUserDto;
import com.metropol.demobank.dto.UserLoginDto;
import com.metropol.demobank.exception.CustomException;
import com.metropol.demobank.model.User;
import com.metropol.demobank.repository.UserRepository;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/auth")
public class AuthenticationController extends Controller{
    private final AuthenticationManager authenticationManager;

    private final TokenProvider jwtTokenUtil;

    private final UserRepository userService;

    @Autowired
    public AuthenticationController(AuthenticationManager authenticationManager,
                                    TokenProvider jwtTokenUtil,
                                    UserRepository userService) {
        this.authenticationManager = authenticationManager;
        this.jwtTokenUtil = jwtTokenUtil;
        this.userService = userService;
    }

    @PostMapping(value = "/signIn")
    public LoggedInUserDto signIn(@RequestBody UserLoginDto userLoginDto) {
        if (StringUtils.isEmpty(userLoginDto.getUsername())) {
            throw new CustomException("Username is required!");
        } else if (StringUtils.isEmpty(userLoginDto.getPassword())) {
            throw new CustomException("Password is required!");
        }
        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                        userLoginDto.getUsername(),
                        userLoginDto.getPassword()
                )
        );
        User user = userService.findByUsername(userLoginDto.getUsername());
        SecurityContextHolder.getContext().setAuthentication(authentication);
        String token = jwtTokenUtil.generateToken(authentication);
        return new LoggedInUserDto(user, token);
    }
}
